/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.giarre.classes;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author giarr
 */
public class Gioco implements Serializable{
    String[][] board;
    String[][] soluzione;
   public Gioco(){
       board = new String[9][9];
       soluzione = new String[9][9];
       for(int i =0; i<9;i++){
           
           for(int j=0; j<9;j++){
               soluzione[i][j]="-1";
           }
       }
   }
  
    
   public Gioco(ResultSet ris){
      
       String[] soluzionetmp;
         this.soluzione = new String[9][9];
         this.board = new String[9][9];
        try {
            while(ris.next()){
          soluzionetmp  = ris.getString("SOLUTION").split(" ");
          for(int i = 0; i<9; i++){
            for(int j=0; j<9; j++){
                this.soluzione[i][j] = soluzionetmp[i*9+j];
                this.board[i][j]="-1";
            }
          
          String[] boardtmp = ris.getString("FIXEDCELLS").split(" ");
          for(String s: boardtmp){
              String[] tmp = s.split("");
              int tmpx = Integer.parseInt(tmp[0])-1;
              int tmpy = Integer.parseInt(tmp[1])-1;
              this.board[tmpx][tmpy] = this.soluzione[tmpx][tmpy];
          }
        }}
        } catch (SQLException ex) {
            Logger.getLogger(Gioco.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
 
    public void stringona(){
        for(int i=0; i<9; i++){
            for(int j=0; j<9; j++){
                System.out.println(soluzione[i][j] + " ");
            }
        }
    }
    public String[][] getBoard() {
        return board;
    }

    public void setBoard(String[][] board) {
        this.board = board;
    }

    public String[][] getSoluzione() {
        return soluzione;
    }

    public void setSoluzione(String[][] soluzione) {
        this.soluzione = soluzione;
    }
}
