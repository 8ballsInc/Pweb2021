/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classi;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author giarr
 */
public class Messaggio implements Serializable{
    public String testo;
    public Date data;
    public String user;
    
    public Messaggio(String txt,String usr){
        this.testo = txt;
        Date d = new Date();
        this.data = d;
        this.user = usr;
    }
    
}
