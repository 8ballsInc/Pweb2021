/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.disi.giarre.classes;

import java.io.Serializable;

/**
 *
 * @author giarr
 */
public class Notizia implements Serializable, Comparable {
    String testo;
    int id;

    public String getTesto() {
        return testo;
    }

    public void setTesto(String testo) {
        this.testo = testo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public Notizia(){}
    public Notizia(String testo,int id){
        this.testo = testo;
        this.id = id;
        processa();
    }
    
    public void processa(){
        if(testo.indexOf("goal")!=-1){
            int index = testo.indexOf("goal");
            String tmp1 = testo.substring(0,index-1);
            String tmp2 = testo.substring(index+4);
            String ris = tmp1 + "<b> goal <b>" + tmp2;
            this.testo = ris;
        }
        
    }

    @Override
    public int compareTo(Object t) {
        Notizia tmp = (Notizia)t;
        if(this.id > tmp.id){
            return -1;
        }else{
            return 1;
        }
    }
}
