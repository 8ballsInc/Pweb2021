/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.giarre.helper;

import javax.servlet.http.HttpSession;

/**
 *
 * @author giarr
 */
public class Initializer {
    public Initializer(HttpSession sessione){
        sessione.setAttribute("nome",null);
        sessione.setAttribute("scelta",null);
    }
    

}
