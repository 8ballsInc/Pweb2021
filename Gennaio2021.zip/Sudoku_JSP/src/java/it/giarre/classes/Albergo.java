/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.giarre.classes;

/**
 *
 * @author giarr
 */
public class Albergo extends Alloggio{


    public Albergo(String nome, int prezzo, float punteggio,int stelle,String img) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.punteggio = punteggio;
        this.extra = translate(stelle);
        this.img = img;
    }

    public String translate(int n){
        return ""+n+" stelle";
    }

    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }
  

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(int prezzo) {
        this.prezzo = prezzo;
    }

    public float getPunteggio() {
        return punteggio;
    }

    public void setPunteggio(int punteggio) {
        this.punteggio = punteggio;
    }
    
    
}
