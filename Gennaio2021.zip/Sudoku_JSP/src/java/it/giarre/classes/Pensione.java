/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.giarre.classes;

/**
 *
 * @author giarr
 */
public class Pensione extends Alloggio{

    
    public Pensione(String nome, int prezzo, float punteggio,int trattamento,String img) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.punteggio = punteggio;
        this.extra = translate(trattamento);
        this.img = img;
    }
    public String translate(int n){
        if(n==1){
            return "Solo prima colazione";
        }
        if(n==2){
            return "Mezza pensione";
        }
        if(n==3){
            return "Pensione completa";
        }
        return "";
    }

public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(int prezzo) {
        this.prezzo = prezzo;
    }

    public float getPunteggio() {
        return punteggio;
    }

    public void setPunteggio(float punteggio) {
        this.punteggio = punteggio;
    }
    
}
