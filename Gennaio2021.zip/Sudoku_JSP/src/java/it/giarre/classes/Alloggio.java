/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.giarre.classes;

import java.io.Serializable;

/**
 *
 * @author giarr
 */
public abstract class Alloggio implements Serializable {
    public String nome;
    public int prezzo;
    public float punteggio;
    public String extra;
    public String img;

   
    
   
    
}
