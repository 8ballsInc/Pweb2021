/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function checkUser(){
    var xhttp = new XMLHttpRequest();
    xhttp.responseType = "json";
    xhttp.onreadystatechange = function(){
        if(this.readyState === 4 && this.status === 200){
            var login = this.response.login;
            console.log(login);
            if(login){
                window.location.replace("/trivago/scelta.html");
            }else{
                window.location.replace("/trivago/benvenuto.html");
            }
        }
    };
    xhttp.open("GET","/trivago/Accesso",true);
    xhttp.send();
}
function getUsername(){
    var xhttp = new XMLHttpRequest();
    xhttp.responseType = "json";
    xhttp.onreadystatechange = function(){
        if(this.readyState === 4 && this.status === 200){
            var nome = this.response.nome;
            console.log(nome);
            document.getElementById("nome_navbar").innerHTML="Bentornato "+ nome;
        }
    };
    xhttp.open("GET","/trivago/Accesso",true);
    xhttp.send();
}

function getCategoria(){
    var xhttp = new XMLHttpRequest();
    xhttp.responseType = "json";
    xhttp.onreadystatechange = function(){
        if(this.readyState === 4 && this.status === 200){
            console.log(this.response);
            var categoria = this.response.categoria;
            var nomecategoria="";
            if(categoria === 1)nomecategoria="Hotel";
            if(categoria === 2)nomecategoria="Pensione";
            if(categoria === 3)nomecategoria="Appartamento";
            document.getElementById("categoria").innerHTML="Hai scelto la categoria: "+ nomecategoria;
        }
    };
    xhttp.open("GET","/trivago/Accesso",true);
    xhttp.send();
}
function getDB(){
    var xhttp = new XMLHttpRequest();
    xhttp.responseType = "json";
    xhttp.onreadystatechange = function(){
        if(this.readyState === 4 && this.status === 200){
           var risultati = this.response.risultati;
           for(var i=0; i<risultati.length-1;i++){
               
               var table = document.getElementById("maintable");
               var rowcount = table.rows.length;
               var newrow = table.insertRow(rowcount);
               
               var cell = newrow.insertCell(0);
               var text = document.createTextNode(risultati[i].nome);
               cell.append(text);
               cell.setAttribute("onclick","getinfo(\""+risultati[i].id+"\")");
           }
        }
    };
    xhttp.open("GET","/trivago/DB",true);
    xhttp.send();
}
function logout(){
    var xhttp = new XMLHttpRequest();
   
    xhttp.open("GET","/trivago/Logoff",true);
    xhttp.send();
    window.location.replace("/trivago/benvenuto.html");
}
function getinfo(id){
     var xhttp = new XMLHttpRequest();
    xhttp.responseType = "json";
    xhttp.onreadystatechange = function(){
        if(this.readyState === 4 && this.status === 200){
         // var risultati = this.response.risultati[0];
          var l1 = document.getElementById("nome");
          var l2 = document.getElementById("punteggio");
          var l3 = document.getElementById("prezzo");
          var kek = document.createNewElement();
          var img = "/"
          l1.innerHTML = this.response.nome;
          l2.innerHTML = this.response.punteggio;
          l3.innerHTML = this.response.prezzo;
        }
    };
    xhttp.open("POST","/trivago/GetInfo",true);
    xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xhttp.send("id="+id);
}
