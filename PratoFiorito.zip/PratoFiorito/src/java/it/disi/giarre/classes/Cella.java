package it.disi.giarre.classes;


import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author giarr
 */
public class Cella implements Serializable{
    int valore;
    boolean coperto;
    
    public Cella(){coperto = true; valore=0;}

    public int getValore() {
        return valore;
    }

    public void setValore(int valore) {
        this.valore = valore;
    }

    public boolean isCoperto() {
        return coperto;
    }

    public void setCoperto(boolean coperto) {
        this.coperto = coperto;
    }
    
    
}
