/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.disi.giarre.classes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author giarr
 */
public class Board {
    public Cella[][] griglia;
    
    public Board(){
        this.griglia = new Cella[9][9];
        for(int i = 0; i<9; i++){
            for(int j=0; j<9; j++){
                griglia[i][j]=new Cella();
            }
        }
        Piazzabombe();
        //Piazzabombe_def();
        Contabombe();
        
    }
    public void Piazzabombe_def(){
        for(int i = 0; i<9;i++){
            for(int j=0; j<9;j++){
                if(i==j){
                    griglia[i][j].setValore(-1);
                }
            }
        }
    }
    public void Piazzabombe(){
        Random r = new Random();
        ArrayList<String> usati = new ArrayList<String>();
        while(usati.size()<9){
            int x = r.nextInt(9);
            int y = r.nextInt(9);
            String tmp = ""+x+y;
            while(usati.contains(tmp)){
                x = r.nextInt(9);
                y = r.nextInt(9);
                tmp = ""+x+y;
            }
            this.griglia[x][y].setValore(-1);
            usati.add(tmp);
        } 
    }
    public void Contabombe(){
        
        for(int i=0; i<9; i++){
            for(int j=0; j<9; j++){
                griglia[i][j].setValore(Conta(i,j));
            }
        }
    }
    public int Conta(int x, int y){
        if(griglia[x][y].getValore()==-1) return -1;
        int ris = 0;
        if(x>0){
            if(griglia[x-1][y].getValore()==-1) ris++;
        }
        if(y>0){
            if(griglia[x][y-1].getValore()==-1) ris++;
        }
        if(y<8){
            if(griglia[x][y+1].getValore()==-1) ris++;
        }
        if(x<8){
            if(griglia[x+1][y].getValore()==-1) ris++;
        }
        if(x<8 && y<8){
            if(griglia[x+1][y+1].getValore()==-1) ris++;
        }
        if(x>0 && y>0){
            if(griglia[x-1][y-1].getValore()==-1) ris++;
        }
        if(x>0 && y<8){
            if(griglia[x-1][y+1].getValore()==-1) ris++;
        }
        if(x<8 && y>0){
            if(griglia[x+1][y-1].getValore()==-1) ris++;
        }
        return ris;
    }
    
}
